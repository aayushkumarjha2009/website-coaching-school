import React from 'react'

function Footer() {
  return (
    <div>
              {/* Footer */}
      <footer className="text-center text-gray-600 text-sm py-4 z-10">
        © 2025 SOSE Tracker. Built for school projects with 💚.
      </footer>
    </div>
  )
}

export default Footer